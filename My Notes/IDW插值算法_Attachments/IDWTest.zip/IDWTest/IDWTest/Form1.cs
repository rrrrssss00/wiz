using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace IDWTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> x = new List<double>();
            List<double> y = new List<double>();
            List<double> z = new List<double>();
            List<double> X = new List<double>();
            List<double> Y = new List<double>();
            StreamReader sr = new StreamReader(Application.StartupPath + @"\Book1.csv");
            string line = "";
            while ((line = sr.ReadLine())!=null)
            {
                string[] tmpArray = line.Split(',');
                x.Add(double.Parse(tmpArray[0]));
                y.Add(double.Parse(tmpArray[1]));
                z.Add(double.Parse(tmpArray[2]));
            }
            sr.Close();

            for (int i = 0; i < 24; i++)
            {
                for (int j = 1; j < 20; j++)
                {
                    X.Add((double)i / 20);
                    Y.Add((double)j / 20);
                }
            }
            List<double> Z =IDW.Interpolate(x, y, z, X, Y);
            StreamWriter sw = new StreamWriter(Application.StartupPath + @"\Book2.csv");
            for (int i = 0; i < X.Count; i++)
            {
                sw.WriteLine(X[i] + "," + Y[i] + "," + Z[i]);
            }
            sw.Close();
        }
    }
}